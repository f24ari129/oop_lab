import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Random;

class Oganizing {
  public static final String RESET = "\u001B[0m";
    public static final String RED = "\u001B[31m";
    public static final String GREEN = "\u001B[32m";
    public static final String YELLOW = "\u001B[33m";
    public static final String BLUE = "\u001B[34m";
    static Scanner input = new Scanner(System.in);

    public static void ifAdmin() {
        Random random = new Random();
        System.out.print("Enter the number of rooms: ");
        int numRooms = input.nextInt();
        input.nextLine();

        Room[] rooms = new Room[numRooms];

        for (int i = 0; i < numRooms; i++) {
            System.out.print("Enter room name: ");
            String roomName = input.nextLine();
            System.out.print("Enter the number of seats in " + roomName + ": ");
            int totalSeats = input.nextInt();
            input.nextLine();
            rooms[i] = new Room(roomName, totalSeats);
        }

        Student[] students = new Student[100];
        int index = 0;

        try {
            Scanner scanner = new Scanner(new File("pakistan_names_dataset.txt"));
            while (scanner.hasNextLine() && index < 100) {
                String line = scanner.nextLine();
                if (line.toLowerCase().contains("rollno")) continue;
                String[] data = line.split("\\s+");
                if (data.length >= 3) {
                    students[index++] = new Student(data[0], data[1], data[2]);
                }
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
            return;
        }

        // Shuffle students randomly
        for (int i = index - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);
            Student temp = students[i];
            students[i] = students[j];
            students[j] = temp;
        }

        int studentIndex = 0;
        for (Room room : rooms) {
            for (int j = 0; j < room.totalSeats && studentIndex < index; j++) {
                room.assignSeat(j, students[studentIndex++]);
            }
            room.displayRoomInfo();
            room.saveRoomToFile();
        }
    }

    public static void ifStudent() {
        System.out.println("Student panel activated...\n");

        System.out.print("Enter your roll number: ");
        String searchRollNo = input.nextLine();

        File currentDir = new File("."); // current directory
        File[] files = currentDir.listFiles((dir, name1) ->
            name1.toLowerCase().endsWith(".txt") && !name1.equalsIgnoreCase("pakistan_names_dataset.txt")
        );

        boolean found = false;

        if (files != null) {
            for (File file : files) {
                try (Scanner fileScanner = new Scanner(file)) {
                    while (fileScanner.hasNextLine()) {
                        String line = fileScanner.nextLine();
                        if (line.contains(searchRollNo)) {
                            System.out.println("Student Found!");
                            System.out.println("Details: " + line);
                            System.out.println("Room: " + file.getName().replace(".txt", ""));
                            found = true;
                            break;
                        }
                    }
                } catch (FileNotFoundException e) {
                    System.out.println("Error reading file: " + file.getName());
                }
                if (found) break;
            }
        }

        if (!found) {
            System.out.println("Student with roll number " + searchRollNo + " not found in any room.");
        }
    }
}
class Student {
    String rollNo;
    String name;
    String subject;

    Student(String rollNo, String name, String subject) {
        this.rollNo = rollNo;
        this.name = name;
        this.subject = subject;
    }

    @Override
    public String toString() {
        return String.format("| %-6s | %-12s | %-20s |", rollNo, name, subject);
    }
}

class Room {
    String nameRoom;
    int totalSeats;
    Student[] seats;

    Room(String nameRoom, int totalSeats) {
        this.nameRoom = nameRoom;
        this.totalSeats = totalSeats;
        this.seats = new Student[totalSeats];
    }

    void assignSeat(int seatNumber, Student student) {
        if (seatNumber >= 0 && seatNumber < totalSeats) {
            seats[seatNumber] = student;
        }
    }

    void displayRoomInfo() {
        System.out.println("\nRoom: " + nameRoom);
        System.out.println("Total Seats: " + totalSeats);
        for (int i = 0; i < totalSeats; i++) {
            if (seats[i] != null) {
                System.out.println("Seat " + (i + 1) + ": " + seats[i]);
            } else {
                System.out.println("Seat " + (i + 1) + ": Empty");
            }
        }
    }

    void saveRoomToFile() {
        try (FileWriter writer = new FileWriter(nameRoom + ".txt")) {
            writer.write("Room: " + nameRoom + "\n");
            writer.write("Total Seats: " + totalSeats + "\n");
            for (int i = 0; i < totalSeats; i++) {
                if (seats[i] != null) {
                    writer.write("Seat " + (i + 1) + ": " + seats[i] + "\n");
                } else {
                    writer.write("Seat " + (i + 1) + ": Empty\n");
                }
            }
            System.out.println("Room arrangement saved to " + nameRoom + ".txt");
        } catch (IOException e) {
            System.out.println("Error saving file for room: " + nameRoom);
        }
    }
}

public class FileReader extends Oganizing {
    public static void main(String[] args) {
 int press_button=0;        
        String name;
    
String again;
        Scanner getname = new Scanner(System.in);
Scanner getbutton = new Scanner(System.in);
Scanner getagain = new Scanner(System.in);
        System.out.println(RED+"Please Enter Yuor Identity (by Name) :");

name=getname.nextLine();
if(name.equalsIgnoreCase("Sajjad Rajper")){
do{
System.out.println(BLUE+"Sir,How can I can you? \n 1>press 1 for Seat_Assigning.\n 2>press 2 for Checking any Student Seat. \n 3>press 3 for Quit. \n PLease press:");
press_button=getbutton.nextInt();
switch(press_button){
case 1:
ifAdmin();break;
case 2:
ifStudent(); break;
case 3:
System.out.println(BLUE+"THANKS FOR USING ME");
System.out.println(RESET);
return;
default:
System.out.println("Sir,You Mistakenly Entered Wrong...");break;}
System.out.println(YELLOW+"Sir,Did you want help Again (yes/no)");
again=getagain.nextLine();
}while(again.equalsIgnoreCase("yes"));
System.out.println(BLUE+"THANKS FOR USING ME");
}
else{ 
System.out.println(GREEN+"How can I can you? \n 1>press 1 for Checking any Student Seat. \n 2>press 2 for Quit. \n PLease press:");
press_button=getbutton.nextInt();
switch(press_button){
case 1:
ifStudent();break;
case 2:
System.out.println(BLUE+"THANKS FOR USING ME");
return;
default:
System.out.println("Sir,You Mistakenly Entered Wrong...");break;}
}
}
}