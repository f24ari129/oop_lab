/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculator;
/**
 *
 * @author KABIR BALOCH
 */
public class Calculator {

    public static void main(String[] args) {
   
    }
}
